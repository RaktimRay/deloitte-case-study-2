from django.shortcuts import render
from pathlib import Path
import pickle

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent


def home(request):
    return render(request,'home.html')

def showdata(request):
    gender = request.GET['gender']
    gen  = 0
    if  gender.lower() == 'male':
        gen = 1
    else:
        gen = 0
    time = int(request.GET['time'])
    pick_time = int(request.GET['picktime'])
    travel_time = int(request.GET['traveltime'])
    model_path = f'{BASE_DIR}\\admission\\lrmodel.sav'
    file = open(model_path,'rb')
    model = pickle.load(file)
    res= model.predict([[gen,time,pick_time,travel_time]])
    

    return render(request, 'home.html',{'res':res[0]})